# Archive Analysis

Assess archive contents and delivery risks without executing members.

**Input:** Archive listing, member metadata, nested structure, hashes and delivery context.

**Result:** Member inventory, handling limits and delivery/execution hypothesis.

Download [archive-analysis.zip](../../../dist/chatgpt/archive-analysis.zip) and import one package in a compatible Skills interface. Name the skill and attach relevant evidence. The package includes the workflow, a focused analysis guide, reviewed primary-source links and optional connection guidance. It contains no classroom/demo payloads, API keys or active service connection.

**Validation:** Source and package review; no claim of end-to-end model or SIEM effectiveness. Configure integrations separately and validate any generated queries/configuration against your actual backend. See [analysis guidance](references/analysis.md) for meaningful acceptance criteria and limitations.

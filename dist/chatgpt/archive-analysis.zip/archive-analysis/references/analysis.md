# Archive Analysis: analysis guide

## Evidence contract

Use archive listing, member metadata, nested structure, hashes and delivery context. Preserve original field names and record/object identifiers. If only an alert summary is supplied, identify which assertions originate from the alert and which are independently corroborated. The following checks define this skill's scope:

- **Check 1:** Check extension/content mismatches and path traversal or symlink entries.
- **Check 2:** Identify shortcut/script/executable chains and nested or encrypted members.
- **Check 3:** Use bounded listing/extraction only in an authorized isolated workspace.

## Interpret the source

Record exact artifact hash, acquisition method, time, parser/tool version and any transformations. Work from inert text/parser output or controlled offline tooling when available. Never execute a sample to clarify a static hypothesis. Preserve original bytes and separate capabilities suggested by structure from behavior actually recorded. A hash lookup identifies a provider report, not necessarily current behavior on the investigated asset.

## Discriminate and correlate

Consider software packages and encrypted business documents can contain executable or opaque members. Identify an observation that supports or contradicts that explanation, such as an approved change, expected owner, source-specific result or downstream artifact. An allowlisted tool name or a familiar account is not enough to close the case.

Next evidence: correlate delivery, extraction and subsequent endpoint execution evidence. State the entity keys, start/end time and expected observation before proposing a search. Use actual schema samples; label field names that still require verification. Do not broaden an exact artifact or destination into an unrelated organization-wide hunt by default.

## Output and acceptance criteria

Return member inventory, handling limits and delivery/execution hypothesis. Include evidence provenance, uncertainty and proportionate next checks. Explain the limitation: an encrypted or suspicious archive is not proof that its contents executed.

For an investigation example, the assessment should change when decisive corroboration is removed; an ambiguous input should remain inconclusive. For an engineering artifact, validate its actual target engine, schema and intended behavior. Reference review and correct packaging do not establish backend execution or measured production effectiveness.

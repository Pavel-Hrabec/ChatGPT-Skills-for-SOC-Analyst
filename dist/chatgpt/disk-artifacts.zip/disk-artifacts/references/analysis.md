# Disk Artifacts: analysis guide

## Evidence contract

Use image/source metadata, filesystem timeline, journal/file records and hash information. Preserve original field names and record/object identifiers. If only an alert summary is supplied, identify which assertions originate from the alert and which are independently corroborated. The following checks define this skill's scope:

- **Check 1:** Preserve acquisition provenance and original timestamps.
- **Check 2:** Distinguish file creation, modification, access and metadata changes.
- **Check 3:** Correlate journal and directory records with independently observed process activity.

## Interpret the source

Record exact artifact hash, acquisition method, time, parser/tool version and any transformations. Work from inert text/parser output or controlled offline tooling when available. Never execute a sample to clarify a static hypothesis. Preserve original bytes and separate capabilities suggested by structure from behavior actually recorded. A hash lookup identifies a provider report, not necessarily current behavior on the investigated asset.

## Discriminate and correlate

Consider restoration, copying, installer operations and timestamp preservation affect filesystem times. Identify an observation that supports or contradicts that explanation, such as an approved change, expected owner, source-specific result or downstream artifact. An allowlisted tool name or a familiar account is not enough to close the case.

Next evidence: pivot to execution and account artifacts within a bounded incident window. State the entity keys, start/end time and expected observation before proposing a search. Use actual schema samples; label field names that still require verification. Do not broaden an exact artifact or destination into an unrelated organization-wide hunt by default.

## Output and acceptance criteria

Return filesystem evidence timeline with explicitly qualified execution claims. Include evidence provenance, uncertainty and proportionate next checks. Explain the limitation: a file timestamp or presence alone does not prove execution or the responsible actor.

For an investigation example, the assessment should change when decisive corroboration is removed; an ambiguous input should remain inconclusive. For an engineering artifact, validate its actual target engine, schema and intended behavior. Reference review and correct packaging do not establish backend execution or measured production effectiveness.

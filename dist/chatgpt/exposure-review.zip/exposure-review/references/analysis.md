# Exposure Review: analysis guide

## Evidence contract

Use asset identity, listeners, network paths, cloud/firewall policy and authenticated configuration evidence. Preserve original field names and record/object identifiers. If only an alert summary is supplied, identify which assertions originate from the alert and which are independently corroborated. The following checks define this skill's scope:

- **Check 1:** Separate internet-facing metadata from a verified reachable path.
- **Check 2:** Examine access controls, proxies and effective routing without launching a scan.
- **Check 3:** Tie exposure to the exact vulnerable feature and identity prerequisites.

## Interpret the source

Bind a finding to an exact asset, product/component, build, configuration and observation date. Vendor advisories and authenticated evidence establish applicability. Known exploitation, predicted exploitation probability, technical severity and business impact answer different questions. Stale inventory and changed scan credentials can distort before/after comparisons. Validation should use configuration/version evidence instead of running an exploit.

## Discriminate and correlate

Consider stale inventories, private endpoints and reverse proxies can distort apparent exposure. Identify an observation that supports or contradicts that explanation, such as an approved change, expected owner, source-specific result or downstream artifact. An allowlisted tool name or a familiar account is not enough to close the case.

Next evidence: request existing path-validation evidence and review related security telemetry. State the entity keys, start/end time and expected observation before proposing a search. Use actual schema samples; label field names that still require verification. Do not broaden an exact artifact or destination into an unrelated organization-wide hunt by default.

## Output and acceptance criteria

Return service-specific exposure model and verified versus assumed paths. Include evidence provenance, uncertainty and proportionate next checks. Explain the limitation: a configured allow rule or public IP does not by itself prove end-to-end reachability.

For an investigation example, the assessment should change when decisive corroboration is removed; an ambiguous input should remain inconclusive. For an engineering artifact, validate its actual target engine, schema and intended behavior. Reference review and correct packaging do not establish backend execution or measured production effectiveness.

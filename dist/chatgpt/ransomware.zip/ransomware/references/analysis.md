# Ransomware: analysis guide

## Evidence contract

Use file changes, process/network events, ransom artifacts, backup logs and affected asset inventory. Preserve original field names and record/object identifiers. If only an alert summary is supplied, identify which assertions originate from the alert and which are independently corroborated. The following checks define this skill's scope:

- **Check 1:** Distinguish bulk encryption/rename behavior from legitimate batch operations.
- **Check 2:** Correlate the initiating process with recovery impairment and lateral activity.
- **Check 3:** Establish affected files and systems using observed evidence.

## Interpret the source

Record exact artifact hash, acquisition method, time, parser/tool version and any transformations. Work from inert text/parser output or controlled offline tooling when available. Never execute a sample to clarify a static hypothesis. Preserve original bytes and separate capabilities suggested by structure from behavior actually recorded. A hash lookup identifies a provider report, not necessarily current behavior on the investigated asset.

## Discriminate and correlate

Consider backup software, migrations and approved encryption tools can modify many files. Identify an observation that supports or contradicts that explanation, such as an approved change, expected owner, source-specific result or downstream artifact. An allowlisted tool name or a familiar account is not enough to close the case.

Next evidence: review initial access, credential use, staging and available recovery evidence. State the entity keys, start/end time and expected observation before proposing a search. Use actual schema samples; label field names that still require verification. Do not broaden an exact artifact or destination into an unrelated organization-wide hunt by default.

## Output and acceptance criteria

Return impact timeline, confirmed scope and proportionate response priorities. Include evidence provenance, uncertainty and proportionate next checks. Explain the limitation: a ransom note or extension alone cannot establish a malware family or full impact scope.

For an investigation example, the assessment should change when decisive corroboration is removed; an ambiguous input should remain inconclusive. For an engineering artifact, validate its actual target engine, schema and intended behavior. Reference review and correct packaging do not establish backend execution or measured production effectiveness.

# Memory Analysis

Interpret memory forensic output for suspicious processes and artifacts.

**Input:** Acquisition metadata, OS/build, memory hash, plugin versions and supplied process/module/network output.

**Result:** Memory artifact assessment with acquisition and plugin limitations.

Download [memory-analysis.zip](../../../dist/chatgpt/memory-analysis.zip) and import one package in a compatible Skills interface. Name the skill and attach relevant evidence. The package includes the workflow, a focused analysis guide, reviewed primary-source links and optional connection guidance. It contains no classroom/demo payloads, API keys or active service connection.

**Validation:** Source and package review; no claim of end-to-end model or SIEM effectiveness. Configure integrations separately and validate any generated queries/configuration against your actual backend. See [analysis guidance](references/analysis.md) for meaningful acceptance criteria and limitations.

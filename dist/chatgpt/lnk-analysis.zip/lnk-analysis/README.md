# LNK Analysis

Analyze Windows shortcut artifacts without opening their targets.

**Input:** Shortcut parser output, target/arguments, working directory, icon path and origin metadata.

**Result:** Shortcut behavior explanation and observed-execution correlation.

Download [lnk-analysis.zip](../../../dist/chatgpt/lnk-analysis.zip) and import one package in a compatible Skills interface. Name the skill and attach relevant evidence. The package includes the workflow, a focused analysis guide, reviewed primary-source links and optional connection guidance. It contains no classroom/demo payloads, API keys or active service connection.

**Validation:** Source and package review; no claim of end-to-end model or SIEM effectiveness. Configure integrations separately and validate any generated queries/configuration against your actual backend. See [analysis guidance](references/analysis.md) for meaningful acceptance criteria and limitations.

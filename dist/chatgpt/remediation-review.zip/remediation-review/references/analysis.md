# Remediation Review: analysis guide

## Evidence contract

Use before/after product/configuration state, change record, rescan evidence and asset inventory. Preserve original field names and record/object identifiers. If only an alert summary is supplied, identify which assertions originate from the alert and which are independently corroborated. The following checks define this skill's scope:

- **Check 1:** Verify that the affected component and running instances changed.
- **Check 2:** Check restarts, superseded builds and replicated deployments.
- **Check 3:** Separate absence of a scanner finding from demonstrated remediation of the original condition.

## Interpret the source

Bind a finding to an exact asset, product/component, build, configuration and observation date. Vendor advisories and authenticated evidence establish applicability. Known exploitation, predicted exploitation probability, technical severity and business impact answer different questions. Stale inventory and changed scan credentials can distort before/after comparisons. Validation should use configuration/version evidence instead of running an exploit.

## Discriminate and correlate

Consider different scan coverage or missing credentials can falsely appear to resolve a finding. Identify an observation that supports or contradicts that explanation, such as an approved change, expected owner, source-specific result or downstream artifact. An allowlisted tool name or a familiar account is not enough to close the case.

Next evidence: review all affected assets and define recurrence or rollback monitoring. State the entity keys, start/end time and expected observation before proposing a search. Use actual schema samples; label field names that still require verification. Do not broaden an exact artifact or destination into an unrelated organization-wide hunt by default.

## Output and acceptance criteria

Return remediation verification record and unresolved asset exceptions. Include evidence provenance, uncertainty and proportionate next checks. Explain the limitation: a clean rescan alone cannot establish remediation if coverage or detection conditions changed.

For an investigation example, the assessment should change when decisive corroboration is removed; an ambiguous input should remain inconclusive. For an engineering artifact, validate its actual target engine, schema and intended behavior. Reference review and correct packaging do not establish backend execution or measured production effectiveness.

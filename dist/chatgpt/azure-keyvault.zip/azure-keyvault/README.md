# Azure Key Vault

Investigate suspicious secret, key or certificate access in Key Vault.

**Input:** Resource diagnostic logs, identity, operation/result, vault access model and network context.

**Result:** Vault-access assessment and defensible secret/key exposure scope.

Download [azure-keyvault.zip](../../../dist/chatgpt/azure-keyvault.zip) and import one package in a compatible Skills interface. Name the skill and attach relevant evidence. The package includes the workflow, a focused analysis guide, reviewed primary-source links and optional connection guidance. It contains no classroom/demo payloads, API keys or active service connection.

**Validation:** Source and package review; no claim of end-to-end model or SIEM effectiveness. Configure integrations separately and validate any generated queries/configuration against your actual backend. See [analysis guidance](references/analysis.md) for meaningful acceptance criteria and limitations.

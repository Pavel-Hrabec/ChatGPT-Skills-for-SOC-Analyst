# PE Analysis: analysis guide

## Evidence contract

Use file hash, PE header/section/import/signature output and origin metadata. Preserve original field names and record/object identifiers. If only an alert summary is supplied, identify which assertions originate from the alert and which are independently corroborated. The following checks define this skill's scope:

- **Check 1:** Check parser consistency and file architecture before interpreting fields.
- **Check 2:** Inspect entry point, section characteristics and imports as behavioral leads.
- **Check 3:** Compare signer/hash evidence and provenance without executing the binary.

## Interpret the source

Record exact artifact hash, acquisition method, time, parser/tool version and any transformations. Work from inert text/parser output or controlled offline tooling when available. Never execute a sample to clarify a static hypothesis. Preserve original bytes and separate capabilities suggested by structure from behavior actually recorded. A hash lookup identifies a provider report, not necessarily current behavior on the investigated asset.

## Discriminate and correlate

Consider packed commercial software and uncommon installers may resemble malware. Identify an observation that supports or contradicts that explanation, such as an approved change, expected owner, source-specific result or downstream artifact. An allowlisted tool name or a familiar account is not enough to close the case.

Next evidence: use authorized existing hash reports and correlate actual endpoint execution evidence. State the entity keys, start/end time and expected observation before proposing a search. Use actual schema samples; label field names that still require verification. Do not broaden an exact artifact or destination into an unrelated organization-wide hunt by default.

## Output and acceptance criteria

Return static capability assessment with exact file identity and untested hypotheses. Include evidence provenance, uncertainty and proportionate next checks. Explain the limitation: packing, entropy, imports or a valid signature alone do not establish maliciousness.

For an investigation example, the assessment should change when decisive corroboration is removed; an ambiguous input should remain inconclusive. For an engineering artifact, validate its actual target engine, schema and intended behavior. Reference review and correct packaging do not establish backend execution or measured production effectiveness.

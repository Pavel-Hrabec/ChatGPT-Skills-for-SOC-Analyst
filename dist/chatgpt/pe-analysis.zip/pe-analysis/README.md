# PE Analysis

Perform static triage of Windows PE files or supplied parser output.

**Input:** File hash, PE header/section/import/signature output and origin metadata.

**Result:** Static capability assessment with exact file identity and untested hypotheses.

Download [pe-analysis.zip](../../../dist/chatgpt/pe-analysis.zip) and import one package in a compatible Skills interface. Name the skill and attach relevant evidence. The package includes the workflow, a focused analysis guide, reviewed primary-source links and optional connection guidance. It contains no classroom/demo payloads, API keys or active service connection.

**Validation:** Source and package review; no claim of end-to-end model or SIEM effectiveness. Configure integrations separately and validate any generated queries/configuration against your actual backend. See [analysis guidance](references/analysis.md) for meaningful acceptance criteria and limitations.

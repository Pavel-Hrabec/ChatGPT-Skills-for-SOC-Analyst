# Patch Priority: analysis guide

## Evidence contract

Use validated findings, KEV/EPSS dates, exposure, criticality, compensating controls and change constraints. Preserve original field names and record/object identifiers. If only an alert summary is supplied, identify which assertions originate from the alert and which are independently corroborated. The following checks define this skill's scope:

- **Check 1:** Confirm asset/product applicability before ranking.
- **Check 2:** Distinguish known exploitation from a probabilistic forecast.
- **Check 3:** Weigh reachability, business impact and verified mitigations with explicit rationale.

## Interpret the source

Bind a finding to an exact asset, product/component, build, configuration and observation date. Vendor advisories and authenticated evidence establish applicability. Known exploitation, predicted exploitation probability, technical severity and business impact answer different questions. Stale inventory and changed scan credentials can distort before/after comparisons. Validation should use configuration/version evidence instead of running an exploit.

## Discriminate and correlate

Consider duplicate findings and stale asset inventory can inflate urgency or counts. Identify an observation that supports or contradicts that explanation, such as an approved change, expected owner, source-specific result or downstream artifact. An allowlisted tool name or a familiar account is not enough to close the case.

Next evidence: produce a reviewable priority queue and bounded verification steps. State the entity keys, start/end time and expected observation before proposing a search. Use actual schema samples; label field names that still require verification. Do not broaden an exact artifact or destination into an unrelated organization-wide hunt by default.

## Output and acceptance criteria

Return evidence-supported remediation order and time-sensitive reassessment triggers. Include evidence provenance, uncertainty and proportionate next checks. Explain the limitation: ePSS is not proof of exploitation and scores do not replace organization-specific prioritization decisions.

For an investigation example, the assessment should change when decisive corroboration is removed; an ambiguous input should remain inconclusive. For an engineering artifact, validate its actual target engine, schema and intended behavior. Reference review and correct packaging do not establish backend execution or measured production effectiveness.
